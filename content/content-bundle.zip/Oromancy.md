abillity to store and hold magic, considered the most volitile and powerful usefull magic. Like electricity. 

tentrik crystals

can channel into weapons