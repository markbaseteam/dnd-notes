If lost i can post a 1 hour ceremony to recieve a new book from my patron, it burns the previous book
It turns to ash when I die
Grimoire 
Book of Shadows

[[Book of Ancient Secrets]]

Thorn Whip cantrips
Casting Time: 1 Action  
**Range:** 30 ft  
**Components:** Verbal and Somatic  
**Duration:** Instantaneous  
You create a long, vine-like whip covered in thorns that lashes out at your command toward a creature in range. Make a melee spell attack against the target. If the attack hits, the creature takes 1d6 piercing damage, and if the creature is Large or smaller, you pull the creature up to 10 feet closer to you.
At higher level This spell’s damage increases by 1d6 when you reach 5th level (2d6), 11th level (3d6), and 17th level (4d6).

Light cantrips
1hr
touch an item no larger then 10 feet in any dimension
sheds bright light 20 ft dim ligth 20ft

Control Fire cantrips
**1 action 60ft**
Instant or 1 hr
-   You instantaneously expand the flame 5 feet in one direction, provided that wood or other fuel is present in the new location. 
- You instantaneously extinguish the flames within the cube. You double or halve the area of bright light and dim light cast by the flame, change its color, or both. The change lasts for 1 hour.
    You cause simple shapes—such as the vague form of a creature, an inanimate object, or a location—to appear within the flames and animate as you like. The shapes last for 1 hour.