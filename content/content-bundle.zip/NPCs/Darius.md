Very Drunk person, does work for professor sparks
Has red dragon in his blood
[[Ellie Spellthief]]'s Father

[[List of NPCs]]