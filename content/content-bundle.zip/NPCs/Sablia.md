Underdark Druid
Runs a magic mushroom hut
[[Truthfall]] "Hired?" her to make the [[Beastland Orb]]
The orbs are Anchors to the planes?
1621
	Response "The seed will be sown"