Bugbear
Owns tivork tavern
knows someone at rosepoint that can tell us about the orb
Knows [[annabell stormkeep]], 
Is aware that I am like Annabell Stormkeep
