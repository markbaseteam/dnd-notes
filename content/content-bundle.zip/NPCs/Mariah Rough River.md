Knife River
Interrogated by the party, works in amber hill as a merc
Gave us the info on the orb by amberhill
