[[List of NPCs]]

looks like royalty 
took the disguise off like a costume
