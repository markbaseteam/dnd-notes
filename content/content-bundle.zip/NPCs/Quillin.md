[[List of NPCs]]
A goddess of knowledge 
who was created from goddes of war and order
[[Hezron]]'s Deity