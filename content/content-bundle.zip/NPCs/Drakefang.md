Red Dragon born with scar on their eye and gold stripe down his back
