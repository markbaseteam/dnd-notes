Halfing singing about Djowleane
Grayis white hair, mutton chops