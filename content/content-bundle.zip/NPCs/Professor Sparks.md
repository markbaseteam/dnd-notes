Possibly the wizard that kidnapped me?
makes contraptions 
made the Auto Gnome schematics

[[List of NPCs]]