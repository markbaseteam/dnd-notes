![[Annabelle.png]]
Changeling
Empress living in [[Oblityan]]
Knows [[tivork]]

#people
