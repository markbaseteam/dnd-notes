 [[List of NPCs]]
 Wizard that captured me 
 [[Victor Foreglory]]'S STEPFATHER?????
  Wants me and Victor Badly
  