Chaotic Neutral 5'7
[[Pact of Tome]]
[[Changeling]]
[[warlock]] 
[[Zentha Rolee]]
[[Backstory]]
###### Tags
[[items]]
[[Story Notes List]]

Proficiencies

**Armor:** [Light Armor](https://roll20.net/compendium/dnd5e/Light%20Armor#h-Light%20Armor)  
**Weapons:** simple [Weapons](https://roll20.net/compendium/dnd5e/Weapons#h-Weapons)  
**Tools:** none  

#PC 

![[Jay OG Form.jpg]]