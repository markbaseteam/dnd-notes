I am [[fey]] not a humanoid

Can change appearance and voice for an action.
cannot change the clothes can change size medium to small

I need to have seen the individual to change into them

[[Zentha Rolee]] Elf Female
[[Elanil Magren]] Elf Male 
[[Stang]] Goblin Male
[[Huldruik Icepick]] Dwarf Male

Female Human Mask
Male Dwarf Mask
Drow Elf Mask
Half-Elf Mask

Languages
Common
Goblin
Dwarvish
Deep Speech
Infernal

**Shapeshifter**. As an action, you assume the physical shape of any Medium or small [humanoid](http://www.5esrd.com/gamemastering/monsters-foes/monsters-by-type/humanoids/) you have seen in the past. Your equipment remains the same, and none of your ability scores change. When disguised as a specific person, you gain advantage on all checks related to maintaining the ruse. Returning to your natural form requires a bonus action. You automatically revert to your true form if you are ever incapacitated for more than a minute.