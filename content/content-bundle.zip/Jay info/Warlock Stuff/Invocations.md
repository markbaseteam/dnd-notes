[[Book of Ancient Secrets]]
Eyes of the Rune Keeper
	Can read all writing

Agonizing Blast
	Add charisma to eldritch blast damage

Armor of Shadows
you can cast mage armor on yourself at will without spending