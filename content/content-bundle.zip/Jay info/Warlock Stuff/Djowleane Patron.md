[[warlock]]
Unkown what it is 
Saw it once during my captivity
Gained the book and powers after seeing it
[[Ellie Spellthief]] is now dedicated to them?