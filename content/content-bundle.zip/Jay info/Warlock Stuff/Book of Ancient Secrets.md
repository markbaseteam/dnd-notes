Can cast 2 spells as rituals 
Can add riruals in my book 2 hrs and 50gp for the inks to inscribe it

[[Invocations]]