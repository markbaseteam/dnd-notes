 [[List of Personas]]
Male Dwarf
          Neutral Good
Bartender 
(The layman's bar where common man came for a cold one after a long day at work.)

used to be an alcoholic but stopped drinking

-   Personality:  I hate to see violence. If I have to break a few knees to keep things civilized, so be it.
-   Ideal: Responsibility.  I always go the extra mile to see that everybody gets home okay. (Good)
    
-   Bond:  Someday I’ll have enough to open my own tavern.
    
-   Flaw: I assume everybody has some kind of skeletons in their closets
    

