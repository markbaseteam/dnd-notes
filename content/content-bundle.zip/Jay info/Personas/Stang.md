 [[List of Personas]]
Male Goblin
Chaotic Nuetral
Smuggler from dawnport

- Personality: I enjoy doing things others believe to be impossible
    
-   Ideal: Daring I am most happy when risking everything
    
-   Bond: I wish to grow my ‘business’ greatly
    
-   Flaw: I will drop everything to solve a riddle
    
