  [[List of Personas]]
**MAIN**
Female Elf
Chaotic Neutral
Sage (Discredited Academic)
I was born on Harthdon 15th 

-   Personality: I am convinced that everyone is trying to steal my secrets
    
-   Ideal: Knowledge, The path to power and self-improvement is through Knowledge
    
-   Bond: I’ve been searching my whole life for the answer to a certain question
    
-   Flaw: Unlocking an ancient mystery is worth the price of a civilization

**Feature: Researcher**
When you attempt to learn or recall a piece of lore, if you do not know that information, you often know where and from whom you can obtain it. Usually, this information comes from a library, scriptorium, university, or a sage or other learned person or creature. Your DM might rule that the knowledge you seek is secreted away in an almost inaccessible place, or that it simply cannot be found. Unearthing the deepest secrets of the multiverse can require an adventure or even a whole campaign.