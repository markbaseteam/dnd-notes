 [[List of Personas]]
Elf Male
Lawful Good 
Acolyte (Mystra God of Magic)
**IS one of the figures of government for Cleolor**

-   Personality: I see omens in every action. The gods try to speak to us, we just need to listen
    
-   Ideal: Tradition. The ancient traditions of worship and sacrifice must be preserved and upheld
    
-   Bond: Everything I do is for the common people
    
-   Flaw: I put too much trust in those who wield power within my temple’s hierarchy.
    
