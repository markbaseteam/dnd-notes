 [[Jay]]- Me
[[Kailah Quem]]-Ella
[[Hezron]], [[Krit]]- Tess
[[Victor Foreglory]]-Kaiden
[[Ellie Spellthief]]- Braden
[[Mettra]]- Ell

#PC