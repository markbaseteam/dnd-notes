Previous: [[Session 12]]
[[Ellie Spellthief]] and [[Kailah Quem]] go to the DragonFruit Inn
[[Darius]] frequents the Drunken Clam, an adventurers guild
[[Krit]] and [[Jay]] to the DragonFruit
A plague doctor took [[Victor Foreglory]] behind a palm tree and disappeared
[[Singing Halfing]] singing about Djowleane, asks to save their soul, and how they will destroy the world
We go to the Drunken Clam
Ellie asked where Darius is and got laughed at and got free drinks
Ellie drinks a super strong drink and gets blackout
[[Drakefang]] enters and leaves, possibly is going for orbs?
[[Ellie Spellthief]] talks to [[Darius]]
[[Professor Sparks]] is the person Darius works for as a lab assistant
the schematics were made by professor sparks
We go meet Professor Sparks
Professor Sparks made the orb for [[Mechanus]]
Delivering the Mechanus orb to Raven Crest Academy to Shodrun BlueMore
Hands a very heavy lead sack
There is a really old door at the top


Next: [[Session 14]]