Previous: [[Session 14]]

[[Stelcar Foreglory]] met us
he is wanting to make the orbs
wants to bring them all together
I signed a contract? Volunteer?
he mentioned Zentha Rolee?
I am possibly Zentha Rolee?????
TruthFall and Stelcar and other mages are working together
He wants us to give him the orbs
Says if we dont give it there will be astral tears
says people in amberhill would protect us from the negative planes
Swears on Quillin to give me the contract for the orbs
They are anchors, specks and fragements of the planes
We are going to see the seed being sown
We come out of the ravencrest academy
I was possibly a student of Elanil Magren
Zentha used to know Stelcar and disappeared and I appeared 
Victor gives me Spell refueling ring
I bring Ellie into service of my patron
We arrive in Scovbar in country of Aviar
We buy a bit of items
We go to the Lifeless Steppes?
We rest before he does the summoning.


Next: [[Session 16]]