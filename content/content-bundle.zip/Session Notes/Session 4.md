Previous: [[Session 3]]
Tivork Gave us Food
Tivorks and Jay didnt get hurt by the orb, Hezron, Ellie, Victor, Buris got hurt
Unkown: More impulsive people do not get shocked
Tivork lets us have the bag of colding promised my life savings.
Geralder Ledlain mossy dwarf tivork says hi
Man won beauty contest against hag was given parchment 
Jay and Ellie had fight and Jay got a bad headache
Jay got cured from the headache
Gnoll eats fox and faces us kills gnolls

Next [[Session 5]]