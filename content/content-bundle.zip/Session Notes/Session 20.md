Previous: [[Session 19]]

we are at stormkeep province, I buy us a donkey and cart, Victor buys the draft horse
we try to look for an apothecary
we talk to a very nice guy who sells us items
I buy cook's utensils
we go to the market to buy some food
we see Krit and he has 5 pounds of oats, and gives me money to buy food
40 varied fruits, 30 packs of salted meat, 30 servings of fish all in victor's bag of colding.
silver haired elven kind of people are dashing around a few miles west of us.
they are fighting something
we get into a fight with spiders, and the figures, I use magic and threads appear and the world remends itself
and we just finish the fight

Next: [[Session 21]]