Previous: [[Session 11]]

Look to find any lights on
The inside of the house looks streched
I go in the chimney
Smoke smells bad, feels like water got out of the toilet
[[Jay]] and [[Ellie Spellthief]] are now in the bathroom
Fought the mushroom guards, the queen comes to the house 
Sablia comes out of the room and talks to the queen
Noble says 1621
[[Sablia]] says "The seed will be sown"
[[Truthfall]] is the name Sablia called the person
asks if she has the anchor
one small step to the great plan
[[Bytopia]] and the mountains of [[Celestia]] will be made 
has anchor to [[Hades]] and the [[Abyss]]
sent people to make [[Mechanus]] and [[Limbo]]
wants our orbs
She left and has pages about the orbs
[[Jay]], [[Krit]], and [[Victor Foreglory]] decided to talk to sablia for directions to dawnport
Ellie and Kailah go to center of town for teleportation circle
Me, Krit and [[Victor Foreglory]] (Drag) teleported to Dawnport


Next: [[Session 13]]