Previous: [[Session 7]] 
Heard knocking
Decided to go to rosepoint
Found Kailah in a cupboard
Went to the 5 seasons HQ
Found a weather/scrying staff from Buris
saw tivork and buris putting the earth symbol on trees, tivork was smashing trees
Sees a giant walking next to us as we are heading to burisss
fought a frost giant
Defeated it and did more orb testing
Buris is making the beastlands orb
Sablia, underdark tent
Sablia had someone help give her the idea. 
Ocean druids apprentice is really excited
interrogate the apprentice
Apprentice Died

Next: [[Session 9]]