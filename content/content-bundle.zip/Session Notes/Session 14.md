Previous: [[Session 13]]

[[Kailah Quem]] tries to go into the towers top floor
We use the carriage to head to Amberhill
We fight [[Drakefang]] and we find [[Victor Foreglory]] next to him
[[Mariah Rough River]] teleported [[Drakefang]] and showed us our wanted portraits
we are wanted for conspiracy
[[Victor Foreglory]] (alive) and [[Jay]] (Alive or dead) are worth 500gp
[[Ellie Spellthief]] (Alive or dead)is worth 100 gp
[[Mettra]] (Alive) worth 4gp
[[Kailah Quem]] (Alive or dead) is worth 105gp
the date is 7/21/776
True ebbonn cloaks take the bounties 
We decide to be false prisoners
We get turned into the guard post with fake orbs
we go to the main castle of amberhill
Set in a dungeon and I see the wizard
Jay and Victor see the wizard

Next: [[Session 15]]