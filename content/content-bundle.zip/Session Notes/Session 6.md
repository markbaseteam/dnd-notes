Previous: [[Session 5]]
Starts traveling to Milsalond
get to Milsalond
talked how to get the money that Jay is owed
Draw a sketch of the bank
Got the money
saw there were 2 posters one for family and one for tavern
Ellie stays with us
Goes to the library that I was kidnapped from 
met berta at the library
Victor Paid his guild fee for 2 months
The new orb is related to the 9 hells
Ellie and Jay and Hezron go to the woods to shoot the orb

Next: [[Session 7]]