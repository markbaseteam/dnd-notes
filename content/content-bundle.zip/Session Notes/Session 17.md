Previously: [[Session 16]]

We wake up and see tivork in another cage
I try waking up tivrork and I see, a goblin instead named stang
they sacrifice stang we get the orb 
we kill the cultists and fight the rest
Kailah kills one and I kill a big one
and rip the arm off of one, and they let us go
We enter amberhill
stayed the night in victor's guild
Krit offered to bring us to the dessert


Next: [[Session 18]]