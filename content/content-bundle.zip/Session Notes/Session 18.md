Previous: [[Session 17]]

we go to teleport to Obsidian Reach
Tessa retcons like 6 times
we get our names taken and we get led to Krit's friend
the sun is very hot and its a long straight away, we see a tall western tower at the end
we go to a shop and Krit gets a gun
we go to the bright beholder
Krit uses secret codes to bartender
I buy a beholder drink
I feel like I have 10 eyes 
We get lead to the backroom
Krit takes a knee and I don't and I get zapped, and I collapse and become paralyzed
[[Djowleane Patron]] is an aberrant? one of the big three
One with no head, skull for head, looks like mushroom.
[[Oromancy]], the aberrant thrive off of magic, it is the only one that they cannot use and control
No way to stop it from arriving, they have influence outside this realm. 
An oromancy artifact used to be in aurora post, isn't useful?
the rest of the artifacts are kept secret or in the ruins of oblitian
Oblityan are splintered and was irradiated with magical shrouds, makes it difficult for magical people to continue, known as mages hell
we have an errand, find something pretty for him. 
The curtain comes back and we see that Chog is a beholder, and he paralyzes me again and Victor gets flown in the air and we get robbed
I try to punch Krit, they bite me, and I do hellish rebuke 
Krit goes to the hungry wall inn, we go to the vengeful duck.

Next: [[Session 19]]