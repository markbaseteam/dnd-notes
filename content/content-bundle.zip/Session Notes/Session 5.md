Previous [[Session 4]]
Solves the puzzle and enters The moaning mountains
I change
go into tavern and meet a red genasi: Ember
Geralder Ledlain owns Torchflint herb distribution center
Soot moss; peppery moss and smoke, like tobacco   
we killed all but one in a family in amberhill?
got into a fight with a glowing thing and 5 robed figures. 
Set fire to many buildings and people
Ember is the ball 
Ember dies and says dawnport is the past and future for Ellie
"The next step requires a large sacrifice. Our mutual fiend says that a small group of around 30 would do. After that he would be willing to give us anything we needed. The Seed is almost ours.
-S, M, W, & R"
Scroll of find familar
there is a [[Nine Hells Orb]] with runes and symbols on it. 
new orb operates differently and hurt Jay, hezron
Ellie promises me to pay me money back at milsalond



Next [[Session 6]]