Previous: [[Session 20]]

We get back on the road after the people start looting the spiders
we see the ruins of a big metropolis
we see a town square, large circular pedestal of a war forged statue
250-500 year old statue with eyes glowing
people have been scavenging around here
we see a green and purple skinned people and a robot
they look at the statue
w esay we will help get the artifact to buy it
we go to a police station
10g wporth of electrum
Krit puts on a ring and become female
I remove the curse
We see some spires in the distance
we see a garage like factory and haven't gone their yet
We head to the factory then the spire
Say we are friends of Limbo-7
we get a limbo-7 card
we rest before we leave
we fight a gelatinous cube
I get burned from the acid
We lost all magic items then got em back
I killed the slime

Next: [[Session 22]]
