  Previous: [[Session 6]]
I investigate where I got kidnapped, next to the building of the alleyway has a crooked rotten sign saying, The Guilded Unicorn, 
walked into the guilded unicorn, 
met an unamed person who was from poisson, [[Mettra]]
Got into a fight with theives
Collected a blunderbuss and 10 ammos [[items]]
we interrogate [[Mariah Rough River]], a bandit
learn that thye were hired to make the orbs, all the orbs are tied to the outer planes
New orb will happen in the north east, between dead mans alley and amber hill. wooded area.

Next: [[Session 8]]