Previous: [[Session 18]]

We go to the tavern to wait for Krit
I get beckoned and cloacked figures ask whitetail if its the person, its drakefang, Mariah, [[Kailah Quem]]
Kailah hands me a note
"Krit with me, hears the other one, from Jake"
They have another job
We go to a teleporter to go to gray harbor, to get a boat to Oblityan
We head to rosepoint to find Lye
We go to the daily Kenku and wait inside to see him
We see auto gnomes working
We head to Lye's home
we go downstairs as we hear voices. 
They ask if we are trustworthy, the Aarocockra gives Kailah a hug? or pat, on shoulder. 
Annabell is here?
Annabell takes us to Oblytian
We need to go to naxus to get an artifact, the center old capital
yeet


Next: [[Session 20]]