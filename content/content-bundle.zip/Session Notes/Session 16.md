Previous: [[Session 15]]

Stelcar adds the orbs together
4 arms and millions of tentacles come out 
we get attacked as she screams 
I fall unconsious and Victor does as well
Krit babbles and Ellie is stunned
[[Stelcar Foreglory]] disappears when Djowlene looks at him 
[[Krit]] gets supercharged
most of the party gets buffed
[[Djowleane Patron]] kills a few wizards
Stelcar is back and looks mad
I am deafend and blossom is paranoid dis on wis and cha checks
Victor attacks Djowlene and his father
Djowlene is killing the wizards
We almost used the wished spell
Everyone dies and the world is taken over
Plaugue doctor stops time and takes me to the party in a doorway and explains he watches over all the timelines
he works and lives in candlekeep, we are in his office
[[Jake]] is his name
He will put us back with all our memories
The last group messed up the timeline
We are all in the cages a few weeks earlier
He will try not to make paradoxes, do not touch our past selves
We are in the Cages

Next: [[Session 17]]