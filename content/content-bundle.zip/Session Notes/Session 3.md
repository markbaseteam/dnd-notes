Previous [[Session 2]]

1 day away from Rosepoint
found goblins with a tiny wheel barrow, convinced them to let the other 2 pc's go
Tivork went to find a place to sleep
Went to church
Female red skin tiefling cleric, named [[Yavine]]
offered place of refuge at the church
They worship the god of light and darkness
wrote with yavina
[[Ulril Boromannin]] half elf comes back with blue robes
we show him the orb and he takes it and looks at it and keeps 
got kicked out of general store
I went back into it and bought 2 common clothes and a waterskin
We go to the five seasons HQ 
Buris walks in and wants to sleep in the barn

Next: [[Session 4]]