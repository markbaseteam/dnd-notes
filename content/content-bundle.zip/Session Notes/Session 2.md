Previous: [[Session 1]]

Met [[tivork]] and talked about the orb
lye runs the paper, Yavine
2 other pc's went through a door and the door disappeared 
Alfred and Princess Destructo Unicorn the donkeys
Attacked by 2 wood elves, shot me 3 times
found a paper with pictures of everyone but tivork with me with 100gp bounty wanted dead, for
	[[Pandamonium Orb]]
Found 3 awake dwarves 2 sleeping humans narrowly escaped 

Next: [[Session 4]]