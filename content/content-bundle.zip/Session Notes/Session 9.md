Previous: [[Session 8]]

Grasslands druid starts chanting and his eyes go green, they all summon creatures
Started a fight with buris' wendigo 
Ellie killed the wendigo
Orb is now made
See notes on [[Beastland Orb]] Stats
Gave the orb to [[Sablia]]
Stole the orb 
Moaning mountains has entrance to the underdark
vicqurikillth, ask around
Lost the orb
Went to Torchflint Herbal Distribution
Lockpick into the center
very hot past one door
[[Professor Sparks]] made the autognome
see a bunch of trees in the room, bottom of tree has pitch black steel wool looking thing
grabbed the soot moss and got caught by an auto gnome, dire wolf showed up


Next: [[Session 10]]