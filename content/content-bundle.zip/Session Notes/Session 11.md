Previous: [[session 10]]

Entered the underdark city
go into Hezron's church
[[Kailah Quem]] is found in the church
chase a cloaked figure
goes into a hidden bar
Meet [[Krit]]
Jay and [[Mettra]] Drank alot
Woke up in a pig pen
Talked to Blossom
woke up in a pig pen
stuck in a well
ask some people about [[Sablia]]
seen around town in shops, she sells edible foods


Next: [[Session 12]]