cultists try to sacraficed us
Thrown person in the glowing pit, light goes into the person and the person got crumpled into a palm sized crystal [[Pandamonium Orb]]
Instant kill everyone
[[Pandamonium Orb]] from [[Plane of Pandamonium]]
exit into a house in [[Amberhill]]
Stayed in guild room

Next :[[Session 2]]