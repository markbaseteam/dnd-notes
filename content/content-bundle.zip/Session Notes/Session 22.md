Previous: [[Session 21]]

We get to the facility
we try to lift something up, I step on victors foot and Kailah luckily lifts it
We investigate the room, Victor finds brown liquid
We go upstairs, we can go straight or left, we go left
first left door, there is an arrow trap on the wall, we go straight ahead
we get into a fight with a beholder? and 3 red insects, we hear booms, and bangs
a warforged enters and helps us fight
1 pp and 1gp for artifact, 1pp 110gp
he tells us that we help clear this place out and we can get some artifacts
It is an infestation
we go exploring
We get a map of the building
we are in the center room, I find, 6 spheres of energy, blue crackle, spinning motor inside of them, fuel for relics


Next: [[Session 23]]