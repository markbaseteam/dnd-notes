[[Planes of Existince]]
Safe: Ellie, Victor

Bad: Jay, Hezron, Kailah, Met

