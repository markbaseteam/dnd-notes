Weird frog people called sladds, wild and dangerous. some have been rumored to instantly kill you when they touch you. **DO NOT WANT TO COME TO OUR PLANE**

4 sections of pandamonium, consitantly shifting. No native creatures 