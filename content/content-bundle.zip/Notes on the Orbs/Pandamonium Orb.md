Man turned into the orb
[[Plane of Pandamonium]]
Possible Theory given by [[Ulril Boromannin]]
the planes are all around and overlapping us
the planes are 2 seperate balls, string of twine between the balls needs an anchor, the orb is either the anchor or the twine, something will happen when each is together 

Need a convuluted ritual to activate it, chemical reaction, more potent the orb it the easier the reaction

Weird frog people called sladds, wild and dangerous. some have been rumored to instantly kill you when they touch you. **DO NOT WANT TO COME TO OUR PLANE**