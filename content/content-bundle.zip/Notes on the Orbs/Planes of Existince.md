The planes are on a wheel?
[[Limbo]], and [[Mechanus]] are opposites, pure law and chaos
[[Elysium]] and [[Hades]] are opposites, pure good and evil


[[Pandamonium]] is near limbo?
[[Nine Hells]] is near Hades?

[[Celestia]] is law and good?
[[Beastland Orb]] is chaos and good?
[[Bytopia]] is unkown where it is
