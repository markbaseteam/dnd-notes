Mother, Gwyndolin
Rich girl from a banking family in Milsalond
Can use Fire Magic
spellthief blood line is pure, something special
way back one of the founding parents was a golden dragon
gives a little luck
Darius mom, similar story, a red dragon
thats her powers
Now dedicated to [[Djowleane Patron]]
Knows [[List of player Characters]]
#PC