Kaiden (PC) 
ADOPTED FATHER IS THE WIZARD?????
An alchemist that is in Stokers of the Alkahest, not much known other then that.
Paid his guild fees for 2 months
Disguised as Victoria ForeShame
Knows [[List of player Characters]] 
#PC