#PC
Slender figure
Obssessed with perfection
Lanky and pale
[[Hezron]] is perfect
Flys (Floats?)
Drank a whole bottle of wine
Got drunk with me
Can talk to my frog when drunk

Knows [[List of player Characters]]