[[List of player Characters]]

believed in Gamis
Left for the church in the underdark city near Geralder Ledlain

