 [[List of player Characters]]
7ft tall 
Lizard folk (Aligator)
western clothes
Likes Drinking
Shoots guns and is a bounty hunter
Was a slave? polished guns, and started tinkering with the guns as a child. Started becoming a bounty hunter, tried stealing from an imperial lightning rail, Krit got shot