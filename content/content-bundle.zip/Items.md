A bottle of black ink
a quill
a [small knife](https://www.dndbeyond.com/equipment/small-knife)
a letter from a dead colleague posing a question you have not yet been able to answer
a [set of common clothes](https://www.dndbeyond.com/equipment/clothes-common)
and a pouch containing 10 gp
Yavine book (OtherSide Book) Autographs

• (a)  Quarter staff  1d6 bludgeoning
• (a) a [Component pouch](https://roll20.net/compendium/dnd5e/Component%20pouch#h-Component%20pouch) 
•  [Dungeoneer's Pack](https://roll20.net/compendium/dnd5e/Dungeoneer%27s%20Pack#h-Dungeoneer%27s%20Pack)  
• Leather Armor
2 arrows
Handaxe
two daggers
Blood Vial
Green Wood Elf Cloak
Rose-gold necklace
Silver ring (right hand)
Bag of Colding (Given to [[Krit]])
Empty bottle of invisibility given to [[Victor Foreglory]]
Note for ember
Map of Ellie's House
Missing Person's Poster for Ellie 
Needle
Soot Moss
experimental elixir
cook's utensils
40 varied fruits (in victor's bag of colding)
20 packs of beef jerky
30 servings of fish (in victor's bag of colding)
10gp of electrum
50gp from krit
50gp from Victor
Limbo-7 card
6 blue spheres