Awakened Mind 
I can communicate telepathicaly with a creature 30 feet from me. Dont need to share a language, must be able understand one language
Spell Save DC 8+proficiency+ charisma
Spell attack modifier proficiency plus charisma

Spell Save DC 16
Spell attack modifier +8
[[Invocations]]
**All spells are at 4th level**

Cantrips
Eldritch blast, shot a crackling beam of energy 
**range:** 120ft 
**components** V, S
instant
ranged spell attack on creature on hit do 1d10 force damage + Charisma modifier
2 beams at 5th lvl, 3 at lvl 11, 4 at lvl 17

Chill touch, create a ghostly hand in space of a creature in range, make ranged attack. on hit do 1d8 necrotic damage, and it cannot regain- hit points until the start of your next turn, until then the hand clings to the target.
	If an undead target was hit it also has disadvantage on attack rolls against you until your next turn. 
	The damage increases by 1d8 at lvl 5 11 and 17

Blade Ward
**Casting Time:** 1 action  
**Range:** Self  
**Components:** V, S  
**Duration:** 1 round

You extend your hand and trace a sigil of warding in the air. Until the end of your next turn, you have resistance against bludgeoning, piercing, and slashing damage dealt by weapon attacks.

Thorn Whip
Casting Time: 1 Action  
**Range:** 30 ft  
**Components:** Verbal and Somatic  
**Duration:** Instantaneous  
You create a long, vine-like whip covered in thorns that lashes out at your command toward a creature in range. Make a melee spell attack against the target. If the attack hits, the creature takes 1d6 piercing damage, and if the creature is Large or smaller, you pull the creature up to 10 feet closer to you.
At higher level This spell’s damage increases by 1d6 when you reach 5th level (2d6), 11th level (3d6), and 17th level (4d6).

Light
1hr
touch an item no larger then 10 feet in any dimension
sheds bright light 20 ft dim ligth 20ft 

Control Fire
1 action 60ft
Instant or 1 hr
-   You instantaneously expand the flame 5 feet in one direction, provided that wood or other fuel is present in the new location. 
- You instantaneously extinguish the flames within the cube. You double or halve the area of bright light and dim light cast by th e flame, change its color, or both. The change lasts for 1 hour.
    You cause simple shapes—such as the vague form of a creature, an inanimate object, or a location—to appear within the flames and animate as you like. The shapes last for 1 hour.



Spells 6 known, 4th lvl

Tasha's Hideous Laughter
-   Casting Time: 1 action
-   Range: 30 feet
-   Target: A creature of your choice that you can see within range
-   Components: V S M (Tiny tarts and a feather that is waved in the air)
-   Duration: Up to 1 minute
-   Classes: Bard, Wizard
-   A creature of your choice that you can see within range perceives everything as hilariously funny and falls into fits of laughter if this spell affects it. The target must succeed on a Wisdom saving throw or fall prone, becoming incapacitated and unable to stand up for the duration. A creature with an Intelligence score of 4 or less isn’t affected.  
    At the end of each of its turns, and each time it takes damage, the target can make another Wisdom saving throw. The target has advantage on the saving throw if it’s triggered by damage. On a success, the spell ends.


Hex Lvl 4
**Casting Time:** 1 bonus action  
**Range:** 90 feet  
**Components:** V, S, M (the petrified eye of a newt)  
**Duration:** Concentration, up to 1 hour
You place a curse on a creature that you can see within range. Until the spell ends, you deal an extra 1d6 necrotic damage to the target whenever you hit it with an attack. Also, choose one ability when you cast the spell. The target has disadvantage on ability checks made with the chosen ability. If the target drops to 0 hit points before this spell ends, you can use a bonus action on a subsequent turn of yours to curse a new creature.
	A [Remove Curse](http://dnd5e.wikidot.com/spell:remove-curse) cast on the target ends this spell early.
	**_At Higher Levels._** When you cast this spell using a spell slot of 3rd or 4th level, **you can maintain your concentration on the spell for up to 8 hours.** When you use a spell slot of 5th level or higher, you can maintain your concentration on the spell for up to 24 hours.

Hellish Rebuke Lvl 4
-   **Casting Time:**** Reaction
- **Range: 60 feet**
-   **Target:*** The creature that damaged you
-   **Components:** V, S
-   **Duration:** Instantaneous
-   You point your finger, and the creature that damaged you is momentarily surrounded by hellish flames. The creature must make a Dexterity saving throw. It takes 2d10 fire damage on a failed save, or half as much damage on a successful one.
-   **At Higher Levels:** When you cast this spell using a spell slot of 2nd level or higher, the damage increases by 1d10 for each slot level above 1st.

[[Find Familiar]] Lvl 4


Crown of Madness lvl 4
**Casting Time:** 1 action  
**Range:** 120 feet  
**Components:** V, S  
**Duration:** Concentration, up to 1 minute

One humanoid of your choice that you can see within range must succeed on a Wisdom saving throw or become charmed by you for the duration. While the target is charmed in this way, a twisted crown of jagged iron appears on its head, and a madness glows in its eyes.

The charmed target must use its action before moving on each of its turns to make a melee attack against a creature other than itself that you mentally choose. The target can act normally on its turn if you choose no creature or if none are within its reach.

On your subsequent turns, you must use your action to maintain control over the target, or the spell ends. Also, the target can make a Wisdom saving throw at the end of each of its turns. On a success, the spell ends.

Shatter Lvl 4
-   **Range:** 60 feet
-   **Target:** A point of your choice within range
-   **Components:** V S M (A chip of mica)
-  **Duration:** Instantaneous
-   A sudden loud ringing noise, painfully intense, erupts from a point of your choice within range. Each creature in a 10-foot-radius sphere centered on that point must make a Constitution saving throw. A creature takes 3d8 thunder damage on a failed save, or half as much damage on a successful one. A creature made of inorganic material such as stone, crystal, or metal has disadvantage on this saving throw. A nonmagical object that isn’t being worn or carried also takes the damage if it’s in the spell’s area.
-   **At Higher Levels:** When you cast this spell using a spell slot of 3rd level or higher, the damage increases by 1d8 for each slot level above 2nd. (**Total 5d8**)

Hunger of Hadar Lvl 4
**Casting Time:** 1 action  
**Range:** 150 feet  
**Components:** V, S, M (a pickled octopus tentacle)  
**Duration:** Concentration, up to 1 minute

You open a gateway to the dark between the stars, a region infested with unknown horrors. A 20-foot-radius sphere of blackness and bitter cold appears, centered on a point with range and lasting for the duration. This void is filled with a cacophony of soft whispers and slurping noises that can be heard up to 30 feet away. No light, magical or otherwise, can illuminate the area, and creatures fully within the area are blinded.

The void creates a warp in the fabric of space, and the area is difficult terrain. Any creature that starts its turn in the area takes 2d6 cold damage. Any creature that ends its turn in the area must succeed on a Dexterity saving throw or take 2d6 acid damage as milky, otherwordly tentacles rub against it.

Remove Curse Lvl 4
-   Casting Time: 1 action
-   Range: Touch
-   Target: One creature or object
-   Components: V S
-   Duration: Instantaneous
-   Classes: Cleric, Paladin, Warlock, Wizard
-   At your touch, all curses affecting one creature or object end. If the object is a cursed magic item, its curse remains, but the spell breaks its owner’s attunement to the object so it can be removed or discarded

Elemental Bane Lvl 4
**Casting Time:** 1 action  
**Range:** 90 feet  
**Components:** V, S  
**Duration:** Concentration, up to 1 minute
Choose one creature you can see within range, and choose one of the following damage types: acid, cold, fire, lightning, or thunder. The target must succeed on a Constitution saving throw or be affected by the spell for its duration. The first time each turn the affected target takes damage of the chosen type, the target takes an extra 2d6 damage of that type. Moreover, the target loses any resistance to that damage type until the spell ends.

**At Higher Levels.** When you cast this spell using a spell slot of 5th level or higher, you can target one additional creature for each slot level above 4th. The creatures must be within 30 feet of each other when you target them.

Psychic Lance Lvl 4
**Casting Time:** 1 action  
**Range:** 120 feet  
**Components:** V  
**Duration:** Instantaneous

You unleash a shimmering lance of psychic power from your forehead at a creature that you can see within range. Alternatively, you can utter a creature’s name. If the named target is within range, it becomes the spell’s target even if you can’t see it. If the named target isn’t within range, the lance dissipates without effect.

The target must make an Intelligence saving throw. On a failed save, the target takes 7d6 psychic damage and is incapacitated until the start of your next turn. On a successful save, the creature takes half as much damage and isn’t incapacitated.

**_At Higher Levels._** When you cast this spell using a spell slot of 5th level or higher, the damage increases by 1d6 for each slot level above 4th.